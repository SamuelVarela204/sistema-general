<?php
session_start();
require_once __DIR__ . '/functions.php';

header('Content-Type: application/json');

if (!estaLogueado()) {
    echo json_encode(['exito' => false, 'mensaje' => 'No estás logueado']);
    exit;
}

$accion = $_POST['accion'] ?? '';

if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

switch ($accion) {
    case 'agregar':
        $id = (int)($_POST['id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        $precio = (float)($_POST['precio'] ?? 0);
        $imagen = trim($_POST['imagen'] ?? 'placeholder.png');

        if ($id > 0 && !empty($nombre) && $precio > 0) {
            $encontrado = false;
            foreach ($_SESSION['carrito'] as &$item) {
                if ($item['id'] === $id) {
                    $item['cantidad'] += 1;
                    $encontrado = true;
                    break;
                }
            }
            if (!$encontrado) {
                $_SESSION['carrito'][] = [
                    'id' => $id,
                    'nombre' => $nombre,
                    'precio' => $precio,
                    'cantidad' => 1,
                    'imagen' => $imagen
                ];
            }
            echo json_encode(['exito' => true]);
        } else {
            echo json_encode(['exito' => false, 'mensaje' => 'Datos inválidos']);
        }
        break;

    case 'cambiar_cantidad':
        $index = (int)($_POST['index'] ?? -1);
        $delta = (int)($_POST['delta'] ?? 0);

        if ($index >= 0 && $index < count($_SESSION['carrito'])) {
            $_SESSION['carrito'][$index]['cantidad'] += $delta;
            if ($_SESSION['carrito'][$index]['cantidad'] <= 0) {
                array_splice($_SESSION['carrito'], $index, 1);
            }
            echo json_encode(['exito' => true]);
        } else {
            echo json_encode(['exito' => false, 'mensaje' => 'Producto no encontrado']);
        }
        break;

    case 'eliminar':
        $index = (int)($_POST['index'] ?? -1);
        if ($index >= 0 && $index < count($_SESSION['carrito'])) {
            array_splice($_SESSION['carrito'], $index, 1);
            echo json_encode(['exito' => true]);
        } else {
            echo json_encode(['exito' => false, 'mensaje' => 'Producto no encontrado']);
        }
        break;

    case 'vaciar':
        $_SESSION['carrito'] = [];
        echo json_encode(['exito' => true]);
        break;

    default:
        echo json_encode(['exito' => false, 'mensaje' => 'Acción no válida']);
        break;
}