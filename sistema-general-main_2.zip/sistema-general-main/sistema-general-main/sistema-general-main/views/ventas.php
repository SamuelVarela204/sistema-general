<?php
// Si no está logueado, redirigir al login
if (!estaLogueado()) {
    redirigir('index.php?page=login');
}

$titulo = 'Ventas - Carrito de Compras';
$con = conectarBD();

// Inicializar carrito en sesión si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

$carrito = $_SESSION['carrito'];

// Calcular totales
$subtotal = 0;
foreach ($carrito as $item) {
    $subtotal += $item['precio'] * $item['cantidad'];
}
$iva = $subtotal * 0.19;
$total = $subtotal + $iva;

// Obtener TODOS los productos
$productos = obtenerProductos($con);

// MAPEO DE IMÁGENES: nombre en BD → nombre de archivo
$imagenes = [
    'Jugo de Naranja 500ml' => 'Jugo especial frech.png',
    'Ensalada de Frutas Especial' => 'Ensalada de frutas.png',
    'Porción de Fresas con Crema' => 'placeholder.png',
    'Malteada de Fresa' => 'Malteada de Fresa.png',
    'Malteada de Mango' => 'Malteada de mango.png',
    'Tutifruti' => 'Tutifruti.png',
];
?>

<style>
    /* =============================================
       ESTILOS DEL MÓDULO DE VENTAS
       COLOR PASTEL / ROSA MELOCOTÓN
    ============================================= */
    
    .ventas-container {
        max-width: 1200px !important;
        margin: 0 auto !important;
        padding: 2rem 1.5rem !important;
    }

    /* LOGO CENTRADO Y GRANDE */
    .ventas-logo {
        text-align: center !important;
        margin-bottom: 10px !important;
    }

    .ventas-logo img {
        max-width: 650px !important;
        width: 100% !important;
        height: auto !important;
        display: inline-block !important;
    }

    .ventas-header {
        text-align: center !important;
        margin-bottom: 30px !important;
    }

    .ventas-header .descripcion {
        color: #7a8a9e !important;
        font-size: 1rem !important;
        margin: 6px 0 0 0 !important;
    }

    .ventas-grid {
        display: grid !important;
        grid-template-columns: 1fr 380px !important;
        gap: 30px !important;
    }

    .productos-col {
        background: #ffffff !important;
        border-radius: 20px !important;
        padding: 24px !important;
        box-shadow: 0 4px 20px rgba(0,0,0,0.06) !important;
    }

    .productos-col .titulo {
        text-align: center !important;
        margin-bottom: 4px !important;
    }

    .productos-col .titulo h2 {
        font-size: 1.8rem !important;
        color: #b86b77 !important;
        font-weight: 700 !important;
        letter-spacing: 2px !important;
        margin: 0 !important;
    }

    .productos-col .subtitle {
        color: #7a8a9e !important;
        font-size: 0.95rem !important;
        margin-bottom: 20px !important;
        text-align: center !important;
        margin-left: 0 !important;
    }

    .producto-card {
        display: flex !important;
        gap: 16px !important;
        padding: 14px !important;
        border: 1px solid #f0ecea !important;
        border-radius: 16px !important;
        margin-bottom: 14px !important;
        transition: all 0.3s ease !important;
        background: #ffffff !important;
    }

    .producto-card:hover {
        border-color: #df9cb2 !important;
        box-shadow: 0 4px 15px rgba(223, 156, 178, 0.2) !important;
        transform: translateX(4px) !important;
    }

    .producto-card .thumb {
        width: 72px !important;
        height: 72px !important;
        border-radius: 12px !important;
        flex-shrink: 0 !important;
        overflow: hidden !important;
        background: #f8f5f3 !important;
    }

    .producto-card .thumb img {
        width: 100% !important;
        height: 100% !important;
        object-fit: cover !important;
    }

    .producto-card .info {
        flex: 1 !important;
    }

    .producto-card .info h4 {
        font-size: 1rem !important;
        color: #2d3e50 !important;
        margin: 0 0 2px 0 !important;
    }

    .producto-card .info p {
        font-size: 0.8rem !important;
        color: #7a8a9e !important;
        margin: 0 0 6px 0 !important;
    }

    .producto-card .info .precio {
        font-weight: 700 !important;
        color: #b86b77 !important;
        font-size: 1.1rem !important;
    }

    .btn-agregar {
        padding: 5px 16px !important;
        background: linear-gradient(90deg, #ecbfb1, #df9cb2) !important;
        color: #ffffff !important;
        border: none !important;
        border-radius: 50px !important;
        font-weight: 600 !important;
        font-size: 0.8rem !important;
        cursor: pointer !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08) !important;
    }

    .btn-agregar:hover {
        background: linear-gradient(90deg, #e0a6b9, #d48ba8) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 20px rgba(223, 156, 178, 0.3) !important;
    }

    .cart-col {
        position: sticky !important;
        top: 20px !important;
        align-self: flex-start !important;
    }

    .cart-widget {
        background: #ffffff !important;
        border-radius: 20px !important;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.12) !important;
        overflow: hidden !important;
    }

    .cart-header {
        background: linear-gradient(90deg, #ecbfb1, #df9cb2) !important;
        padding: 18px 22px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
    }

    .cart-header .title-group h3 {
        color: #ffffff !important;
        font-size: 1.3rem !important;
        font-weight: 700 !important;
        margin: 0 !important;
    }

    .cart-header .title-group span {
        color: rgba(255, 255, 255, 0.85) !important;
        font-size: 0.7rem !important;
    }

    .cart-badge {
        background: #ffffff !important;
        color: #b86b77 !important;
        font-size: 18px !important;
        font-weight: 800 !important;
        min-width: 40px !important;
        height: 40px !important;
        border-radius: 50% !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1) !important;
    }

    .cart-body {
        padding: 14px 18px !important;
        max-height: 350px !important;
        overflow-y: auto !important;
        background: #ffffff !important;
    }

    .cart-item {
        display: flex !important;
        gap: 10px !important;
        padding: 10px 0 !important;
        border-bottom: 1px solid #f0ecea !important;
        background: #ffffff !important;
    }

    .cart-item:last-child {
        border-bottom: none !important;
    }

    .cart-item .item-thumb {
        width: 48px !important;
        height: 48px !important;
        border-radius: 10px !important;
        flex-shrink: 0 !important;
        overflow: hidden !important;
        background: #f8f5f3 !important;
    }

    .cart-item .item-thumb img {
        width: 100% !important;
        height: 100% !important;
        object-fit: cover !important;
    }

    .cart-item .item-info {
        flex: 1 !important;
        min-width: 0 !important;
    }

    .cart-item .item-info .name {
        font-size: 0.85rem !important;
        font-weight: 600 !important;
        color: #2d3e50 !important;
    }

    .cart-item .item-info .price {
        font-size: 0.8rem !important;
        color: #b86b77 !important;
        font-weight: 600 !important;
    }

    .cart-item .item-actions {
        display: flex !important;
        align-items: center !important;
        gap: 6px !important;
        margin-top: 3px !important;
    }

    .qty-btn {
        width: 24px !important;
        height: 24px !important;
        border-radius: 50% !important;
        border: 1px solid #e0d8d4 !important;
        background: #ffffff !important;
        cursor: pointer !important;
        font-weight: 700 !important;
        transition: all 0.2s ease !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 14px !important;
        color: #2d3e50 !important;
    }

    .qty-btn:hover {
        background: linear-gradient(90deg, #ecbfb1, #df9cb2) !important;
        color: #ffffff !important;
        border-color: #df9cb2 !important;
    }

    .qty-number {
        font-weight: 600 !important;
        min-width: 24px !important;
        text-align: center !important;
        font-size: 14px !important;
        color: #2d3e50 !important;
    }

    .item-remove {
        background: none !important;
        border: none !important;
        font-size: 14px !important;
        cursor: pointer !important;
        color: #b0a8a4 !important;
        transition: color 0.2s ease !important;
        padding: 2px 4px !important;
    }

    .item-remove:hover {
        color: #b86b77 !important;
    }

    .cart-benefits {
        display: grid !important;
        grid-template-columns: 1fr 1fr !important;
        gap: 4px 12px !important;
        padding: 10px 18px !important;
        background: #faf8f7 !important;
        border-top: 1px solid #f0ecea !important;
        border-bottom: 1px solid #f0ecea !important;
    }

    .cart-benefits .benefit {
        font-size: 0.7rem !important;
        color: #7a8a9e !important;
        display: flex !important;
        align-items: center !important;
        gap: 4px !important;
    }

    .cart-footer {
        padding: 14px 18px !important;
        background: #ffffff !important;
    }

    .cart-total {
        display: flex !important;
        justify-content: space-between !important;
        align-items: center !important;
        margin-bottom: 10px !important;
    }

    .cart-total .label {
        font-size: 0.9rem !important;
        color: #7a8a9e !important;
        font-weight: 500 !important;
    }

    .cart-total .amount {
        font-size: 26px !important;
        font-weight: 800 !important;
        color: #b86b77 !important;
    }

    .btn-checkout {
        width: 100% !important;
        padding: 12px !important;
        background: linear-gradient(90deg, #ecbfb1, #df9cb2) !important;
        color: #ffffff !important;
        border: none !important;
        border-radius: 12px !important;
        font-size: 1rem !important;
        font-weight: 600 !important;
        cursor: pointer !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08) !important;
    }

    .btn-checkout:hover {
        background: linear-gradient(90deg, #e0a6b9, #d48ba8) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 25px rgba(223, 156, 178, 0.35) !important;
    }

    .cart-empty {
        text-align: center !important;
        padding: 25px 15px !important;
        color: #7a8a9e !important;
    }

    .cart-empty .empty-icon {
        font-size: 36px !important;
        display: block !important;
        margin-bottom: 6px !important;
    }

    @media (max-width: 900px) {
        .ventas-grid {
            grid-template-columns: 1fr !important;
        }
        .cart-col {
            position: static !important;
        }
    }

    @media (max-width: 500px) {
        .ventas-container {
            padding: 1rem !important;
        }
        .productos-col {
            padding: 16px !important;
        }
        .producto-card {
            flex-direction: column !important;
            align-items: center !important;
            text-align: center !important;
        }
        .producto-card .thumb {
            width: 64px !important;
            height: 64px !important;
        }
        .cart-benefits {
            grid-template-columns: 1fr !important;
        }
        .cart-header {
            flex-direction: column !important;
            gap: 6px !important;
            text-align: center !important;
        }
        .ventas-logo img {
            max-width: 320px !important;
        }
        .productos-col .subtitle {
            margin-left: 0 !important;
        }
    }

    .cart-body::-webkit-scrollbar {
        width: 4px !important;
    }
    .cart-body::-webkit-scrollbar-track {
        background: transparent !important;
    }
    .cart-body::-webkit-scrollbar-thumb {
        background: #d0c8c4 !important;
        border-radius: 4px !important;
    }
</style>

<div class="ventas-container">

    <!-- =============================================
       LOGO CENTRADO Y GRANDE (650px)
    ============================================= -->
    <div class="ventas-logo">
        <img src="public/images/logo.png" alt="TropicalandFrench - KitiCantino">
    </div>

    <!-- =============================================
       HEADER
    ============================================= -->
    <div class="ventas-header">
        <p class="descripcion">Estás a un paso de disfrutar algo delicioso</p>
    </div>

    <!-- =============================================
       GRID PRINCIPAL
    ============================================= -->
    <div class="ventas-grid">

        <!-- ==========================================
        COLUMNA IZQUIERDA - PRODUCTOS
        ========================================== -->
        <div class="productos-col">
            <div class="titulo">
                <h2>✦ Recomendados Para T&K ✦</h2>
            </div>
            <p class="subtitle">Selecciona lo que quieras y agrégalo al carrito</p>

            <?php foreach ($productos as $prod): 
                $nombreBD = $prod['nom_pro'];
                $archivoImagen = $imagenes[$nombreBD] ?? 'placeholder.png';
            ?>
                <div class="producto-card">
                    <div class="thumb">
                        <img src="public/images/productos/<?= htmlspecialchars($archivoImagen) ?>" 
                             alt="<?= htmlspecialchars($nombreBD) ?>"
                             onerror="this.src='public/images/placeholder.png'">
                    </div>
                    <div class="info">
                        <h4><?= htmlspecialchars($nombreBD) ?></h4>
                        <p><?= htmlspecialchars($prod['descripcion'] ?? 'Sin descripción') ?></p>
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span class="precio">$<?= number_format($prod['precio'], 0, ',', '.') ?></span>
                            <button class="btn-agregar" onclick="agregarAlCarrito(<?= $prod['id_pro'] ?>, '<?= htmlspecialchars($nombreBD) ?>', <?= $prod['precio'] ?>, '<?= htmlspecialchars($archivoImagen) ?>')">
                                + Agregar
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- ==========================================
        COLUMNA DERECHA - CARRITO
        ========================================== -->
        <div class="cart-col">
            <div class="cart-widget">

                <div class="cart-header">
                    <div class="title-group">
                        <h3>Mi Carrito</h3>
                        <span>Estás a un paso de disfrutar algo delicioso</span>
                    </div>
                    <div class="cart-badge" id="badgeGrande">
                        <?= array_sum(array_column($carrito, 'cantidad')) ?>
                    </div>
                </div>

                <div class="cart-body" id="cartBody">
                    <?php if (empty($carrito)): ?>
                        <div class="cart-empty">
                            <span class="empty-icon">🛒</span>
                            <p>Tu carrito está vacío</p>
                            <p style="font-size:0.8rem;">¡Agrega productos para comenzar!</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($carrito as $index => $item): ?>
                            <div class="cart-item" data-index="<?= $index ?>">
                                <div class="item-thumb">
                                    <img src="public/images/productos/<?= htmlspecialchars($item['imagen'] ?? 'placeholder.png') ?>" 
                                         alt="<?= htmlspecialchars($item['nombre']) ?>"
                                         onerror="this.src='public/images/placeholder.png'">
                                </div>
                                <div class="item-info">
                                    <div class="name"><?= htmlspecialchars($item['nombre']) ?></div>
                                    <div class="price">$<?= number_format($item['precio'], 0, ',', '.') ?></div>
                                    <div class="item-actions">
                                        <button class="qty-btn" onclick="cambiarCantidad(<?= $index ?>, -1)">−</button>
                                        <span class="qty-number" id="qty-<?= $index ?>"><?= $item['cantidad'] ?></span>
                                        <button class="qty-btn" onclick="cambiarCantidad(<?= $index ?>, 1)">+</button>
                                        <button class="item-remove" onclick="eliminarItem(<?= $index ?>)">✕</button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div class="cart-benefits">
                    <span class="benefit">✅ 100% Ingredientes naturales</span>
                    <span class="benefit">🌿 Productos frescos cada día</span>
                    <span class="benefit">🚀 Envíos rápidos y seguros</span>
                    <span class="benefit">❤️ Hecho con amor para ti</span>
                </div>

                <div class="cart-footer">
                    <div class="cart-total">
                        <span class="label">Total</span>
                        <span class="amount" id="totalAmount">$<?= number_format($total, 0, ',', '.') ?></span>
                    </div>
                    <button class="btn-checkout" onclick="finalizarPedido()">
                        Ir a pagar →
                    </button>
                </div>

            </div>

            <p style="text-align:center; margin-top:14px; font-size:0.8rem; color:#7a8a9e;">
                🔒 Tus datos están protegidos por el código SSL
            </p>
        </div>

    </div>
</div>

<script>
function actualizarCarrito() {
    location.reload();
}

function cambiarCantidad(index, delta) {
    fetch('includes/actualizar_carrito.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'accion=cambiar_cantidad&index=' + index + '&delta=' + delta
    })
    .then(response => response.json())
    .then(data => {
        if (data.exito) actualizarCarrito();
        else Swal.fire('Error', data.mensaje, 'error');
    });
}

function eliminarItem(index) {
    Swal.fire({
        title: '¿Eliminar producto?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, eliminar'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('includes/actualizar_carrito.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'accion=eliminar&index=' + index
            })
            .then(response => response.json())
            .then(data => {
                if (data.exito) actualizarCarrito();
                else Swal.fire('Error', data.mensaje, 'error');
            });
        }
    });
}

function agregarAlCarrito(id, nombre, precio, imagen) {
    fetch('includes/actualizar_carrito.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'accion=agregar&id=' + id + '&nombre=' + encodeURIComponent(nombre) + '&precio=' + precio + '&imagen=' + encodeURIComponent(imagen)
    })
    .then(response => response.json())
    .then(data => {
        if (data.exito) {
            Swal.fire({
                icon: 'success',
                title: '¡Agregado!',
                text: nombre + ' añadido al carrito',
                timer: 1500,
                showConfirmButton: false
            }).then(() => actualizarCarrito());
        } else {
            Swal.fire('Error', data.mensaje, 'error');
        }
    });
}

function finalizarPedido() {
    const carrito = <?= json_encode($carrito) ?>;
    if (carrito.length === 0) {
        Swal.fire({
            icon: 'warning',
            title: 'Carrito vacío',
            text: 'Agrega productos antes de finalizar el pedido'
        });
        return;
    }

    Swal.fire({
        icon: 'success',
        title: '🎉 ¡Pedido confirmado!',
        html: `<p style="text-align:left;"><strong>Resumen de tu pedido:</strong><br><br>${carrito.map(i => `• ${i.nombre} × ${i.cantidad} = $${(i.precio * i.cantidad).toLocaleString()}`).join('<br>')}<br><br><strong>Total: $${carrito.reduce((sum, i) => sum + (i.precio * i.cantidad), 0).toLocaleString()}</strong></p>`,
        confirmButtonText: '✅ Confirmar compra',
        showCancelButton: true
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('includes/actualizar_carrito.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'accion=vaciar'
            })
            .then(() => {
                Swal.fire({
                    icon: 'success',
                    title: '🎉 ¡Compra exitosa!',
                    text: 'Tu pedido ha sido confirmado.'
                }).then(() => {
                    window.location.href = 'index.php?page=pedidos';
                });
            });
        }
    });
}
</script>